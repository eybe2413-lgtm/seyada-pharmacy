import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export function exportToExcel(filename, rows) {
  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// columns: [{ header: 'الاسم', key: 'name' }, ...]
// rows: array of plain objects matching the keys above
export function exportToPdf({ title, columns, rows, filename }) {
  const docPdf = new jsPDF({ orientation: columns.length > 5 ? 'landscape' : 'portrait' });
  docPdf.setFontSize(14);
  docPdf.text(title, 14, 15);
  docPdf.setFontSize(9);
  docPdf.text(new Date().toLocaleString('fr-FR'), 14, 21);

  autoTable(docPdf, {
    startY: 26,
    head: [columns.map((c) => c.header)],
    body: rows.map((row) => columns.map((c) => formatCell(row[c.key]))),
    styles: { font: 'helvetica', fontSize: 9 },
    headStyles: { fillColor: [14, 124, 102] },
  });

  docPdf.save(`${filename}.pdf`);
}

function formatCell(value) {
  if (value === null || value === undefined) return '';
  if (value && typeof value === 'object' && typeof value.toDate === 'function') {
    return value.toDate().toLocaleDateString('fr-FR');
  }
  if (typeof value === 'number') return value.toLocaleString('en-US');
  return String(value);
}
