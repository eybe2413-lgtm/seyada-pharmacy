import {
  collection,
  doc,
  addDoc,
  updateDoc,
  deleteDoc,
  getDocs,
  query,
  orderBy,
  limit as fbLimit,
  startAfter,
  startAt,
  endAt,
  where,
  Timestamp,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { cacheGet, cacheSet, cacheInvalidate } from './cache';

const PAGE_SIZE = 20;
const col = () => collection(db, 'medicines');

export function computeLowStock(quantity, threshold) {
  return quantity <= (threshold ?? 10);
}

export async function fetchMedicinesPage(cursor = null) {
  let q = query(col(), orderBy('name_lower'), fbLimit(PAGE_SIZE));
  if (cursor) q = query(col(), orderBy('name_lower'), startAfter(cursor), fbLimit(PAGE_SIZE));
  const snap = await getDocs(q);
  return {
    items: snap.docs.map((d) => ({ id: d.id, ...d.data() })),
    lastDoc: snap.docs.length ? snap.docs[snap.docs.length - 1] : null,
    hasMore: snap.docs.length === PAGE_SIZE,
  };
}

export async function searchMedicinesByName(text) {
  const q = text.trim().toLowerCase();
  if (!q) return [];
  const snap = await getDocs(query(col(), orderBy('name_lower'), startAt(q), endAt(q + '\uf8ff'), fbLimit(15)));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}

export async function findMedicineByBarcode(code) {
  const snap = await getDocs(query(col(), where('barcode', '==', code.trim()), fbLimit(1)));
  if (snap.empty) return null;
  const d = snap.docs[0];
  return { id: d.id, ...d.data() };
}

export async function fetchLowStockMedicines() {
  const cacheKey = 'lowstock';
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  const snap = await getDocs(query(col(), where('isLowStock', '==', true), orderBy('name_lower'), fbLimit(50)));
  const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  cacheSet(cacheKey, items, 60000);
  return items;
}

export async function fetchExpiringMedicines(daysAhead = 30) {
  const cacheKey = 'expiring_' + daysAhead;
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  const now = Timestamp.now();
  const cutoff = Timestamp.fromMillis(now.toMillis() + daysAhead * 86400000);
  const snap = await getDocs(query(col(), where('expiryDate', '>=', now), where('expiryDate', '<=', cutoff), orderBy('expiryDate'), fbLimit(50)));
  const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  cacheSet(cacheKey, items, 60000);
  return items;
}

export async function fetchExpiredMedicines() {
  const cacheKey = 'expired';
  const cached = cacheGet(cacheKey);
  if (cached) return cached;
  const now = Timestamp.now();
  const snap = await getDocs(query(col(), where('expiryDate', '<', now), orderBy('expiryDate'), fbLimit(50)));
  const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  cacheSet(cacheKey, items, 60000);
  return items;
}

export async function saveMedicine(med) {
  const quantity = Number(med.quantity) || 0;
  const lowStockThreshold =
    med.lowStockThreshold === '' || med.lowStockThreshold === null || med.lowStockThreshold === undefined
      ? 10
      : Number(med.lowStockThreshold);

  const payload = {
    name: med.name,
    name_lower: med.name.toLowerCase(),
    category: med.category || '',
    barcode: med.barcode || '',
    batchNumber: med.batchNumber || '',
    supplier: med.supplier || '',
    quantity,
    sellPrice: Number(med.sellPrice) || 0,
    costPrice: Number(med.costPrice) || 0,
    lowStockThreshold,
    isLowStock: computeLowStock(quantity, lowStockThreshold),
    expiryDate: med.expiryDate ? Timestamp.fromDate(new Date(med.expiryDate)) : null,
    updatedAt: serverTimestamp(),
  };

  if (med.id) {
    await updateDoc(doc(col(), med.id), payload);
  } else {
    payload.createdAt = serverTimestamp();
    await addDoc(col(), payload);
  }
  cacheInvalidate('lowstock');
  cacheInvalidate('expiring');
  cacheInvalidate('expired');
}

export async function deleteMedicine(id) {
  await deleteDoc(doc(col(), id));
  cacheInvalidate('lowstock');
}

export async function fetchAllMedicinesForValuation() {
  // Used for the inventory-value KPI / inventory report. For extremely
  // large catalogs this could be replaced with a maintained running total,
  // but a single full read here is acceptable since it only runs on demand
  // (Reports screen), not on every dashboard load.
  const snap = await getDocs(col());
  return snap.docs.map((d) => ({ id: d.id, ...d.data() }));
}
